/*
 * Enunciado:
 * Desenvolva um programa capaz de ler uma palavra digitada pelo usu�rio e,
 * a seguir, deve exibir uma string contendo os caracteres da palavra digitada
 * em ordem alfab�tica. Utilize o algoritmo de ordena��o que preferir.
 * O programa deve desconsiderar a diferen�a entre letras ma�usculas e
 * letras min�sculas.
 *
 * Exemplos:
 *
 *   Digite uma palavra: ola
 *   alo
 *
 *   Digite uma palavra: alo
 *   alo
 *
 *   Digite uma palavra: RaceCar
 *   aaccerr
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // Aqui existe a fun��o tolower. Busque documenta��o.

#define MAX 100 // Valor m�ximo para o tamanho do array. N�o modifique.

/* Prot�tipos */

void bubbleSort(char arr[], int tamanho) {
    char a;
    for(int i = tamanho - 1; i > -1; i--){
        for (int j = 0; j < i ; j++){
            if (tolower(arr[j]) > tolower(arr[j+1])){
                a = tolower(arr[j]);
                arr[j] = tolower(arr[j+1]);
                arr[j+1] = a;
            }
        }
    }
}

int main (int argc, char *argv[]){
    char str[MAX];
    printf("digite uma string: ");
    fgets(str, MAX, stdin);
    str[strcspn(str, "\n")] = '\0';
    bubbleSort(str, strlen(str));
    printf("%s", str);
  return 0;
}

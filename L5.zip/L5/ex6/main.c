/*
 * Enunciado:
 * Desenvolva um programa capaz de ler duas palavras digitadas pelo usu�rio e,
 * a seguir, deve inform�-lo se as palavras formam um anagrama. O programa deve
 * desconsiderar a diferen�a entre letras ma�usculas e letras min�sculas.
 *
 * Exemplos:
 *
 * Digite uma palavra: bored
 * Digite uma palavra: robed
 * bored � anagrama de robed
 *
 * Digite uma palavra: bored
 * Digite uma palavra: robbed
 * bored n�o � anagrama de robbed
 *
 * Digite uma palavra: ooi
 * Digite uma palavra: oii
 * ooi n�o � anagrama de oii
 *
 * Digite uma palavra: ooi
 * Digite uma palavra: ioo
 * ooi � anagrama de ioo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // Aqui existe a fun��o tolower. Busque documenta��o.

#define MAX 100 // Valor m�ximo para o tamanho do array. N�o modifique.

/* Prot�tipos */
void bubbleSort(char arr[], int tamanho) {
    char a;
    for(int i = tamanho - 1; i > -1; i--){
        for (int j = 0; j < i ; j++){
            if (tolower(arr[j]) > tolower(arr[j+1])){
                a = tolower(arr[j]);
                arr[j] = tolower(arr[j+1]);
                arr[j+1] = a;
            }
        }
    }
}

int main (int argc, char *argv[]){
    char str_1[MAX], str_2[MAX], aux_1[MAX], aux_2[MAX];
    int tamanho_1, tamanho_2;
    printf("digite uma string: ");
    fgets(str_1, MAX, stdin);
    str_1[strcspn(str_1, "\n")] = '\0';
    tamanho_1 = strlen(str_1);
    strcpy(aux_1, str_1);
    printf("digite uma string: ");
    fgets(str_2, MAX, stdin);
    str_2[strcspn(str_2, "\n")] = '\0';
    tamanho_2 = strlen(str_2);
    strcpy(aux_2, str_2);
    if (tamanho_1 != tamanho_2)
        printf("%s nao e um anagrama de %s", str_1, str_2);
    else{
        bubbleSort(str_1, tamanho_1);
        bubbleSort(str_2, tamanho_2);
        if (strcmp(str_1,str_2) == 0)
            printf("%s e um anagrama de %s", aux_1, aux_2);
        else
            printf("%s nao e um anagrama de %s", aux_1, aux_2);
    }

  return 0;
}

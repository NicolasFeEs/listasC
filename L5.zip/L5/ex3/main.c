/*
 * Enunciado:
 * Desenvolva um programa capaz de ler uma string digitada pelo usu�rio e,
 * a seguir, solicite ao usu�rio que digite um caractere a ser buscado na
 * string digitada. O programa deve informar ao usu�rio se o caractere foi
 * encontrado ou n�o. O programa deve desconsiderar a difere�a entre ma�usculas
 * e min�sculas. Utilize o algoritmo de busca que achar melhor.
 *
 * Exemplos:
 *
 *   Digite uma string: teste!
 *   Digite a chave: !
 *   Caractere ! encontrado na posi��o 5.
 *
 *   Digite uma string: Ola, Mundo!
 *   Digite a chave: M
 *   Caractere m encontrado na posi��o 5.
 *
 *   Digite uma string: Ola, Mundo!
 *   Digite a chave: m
 *   Caractere m encontrado na posi��o 5.
 *
 *   Digite uma string: Ola, Mundo!
 *   Digite a chave: b
 *   Caractere b n�o foi encontrado.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // Aqui existe a fun��o tolower. Busque documenta��o.

#define MAX 100 // Valor m�ximo para o tamanho do array. N�o modifique.

/* Prot�tipos */

int main (int argc, char *argv[]){
    char str[MAX], chave;
    int pos = -1;
    printf("digite uma string:");
    fgets(str, MAX, stdin);
    str[strcspn(str, "\n")] = '\0';
    printf("digite a chave: ");
    setbuf(stdin, 0);
    scanf("%c", &chave);
    chave = tolower(chave);
    for (int i = 0; i < strlen(str); i++){
        if (chave == tolower(str[i])){
            pos = i;
            printf("caractere %c encontrado na posicao %i", chave, pos);
        }
    }
    if (pos == -1)
        printf("caractere %c nao foi encontrado", chave);
  return 0;
}

/* Enunciado:
 * Desenvolva um programa capaz de ler os valores inteiros de uma matriz 3x3
 * e, a seguir, exiba a sua forma transposta
 *
 * Exemplos:
 *
 *
 *    Digite a linha 0: 1 2 3
 *    Digite a linha 1: 4 5 6
 *    Digite a linha 2: 7 8 9
 *    [[1, 4, 7],
 *    [2, 5, 8],
 *    [3, 6, 9]]
 *
 *    Digite a linha 0: 1 0 0
 *    Digite a linha 1: 0 1 0
 *    Digite a linha 2: 0 0 1
 *    [[1, 0, 0],
 *    [0, 1, 0],
 *    [0, 0, 1]]
 *
 */

#include <stdio.h>
#include <stdlib.h>

#define ARRAY_MAX 3 // Valor m�ximo para o tamanho do array. N�o modifique.

int main()
{
    int Matriz[ARRAY_MAX][ARRAY_MAX];
    for (int l = 0; l < ARRAY_MAX; l++){
        printf("digite a linha %i: ", l);
        for (int c = 0; c < ARRAY_MAX; c++){
            scanf("%i", &Matriz[l][c]);
        }
    }
    printf("[");
    for (int c = 0; c < ARRAY_MAX; c++){
            printf("[");
        for (int l = 0; l < ARRAY_MAX; l++){
                printf("%i, ", Matriz[l][c]);
        }
        printf("\b\b]");
        if (c < ARRAY_MAX-1)
            printf("\n");
    }
    printf("]");
    return 0;
}

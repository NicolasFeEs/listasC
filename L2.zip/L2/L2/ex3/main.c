#include <stdio.h>
#include <stdlib.h>

/* Enunciado - Fa�a um programa que receba um n�mero inteiro e, a seguir,
 * exibe todos os seus poss�veis divisores separados apenas por um espa�o.
 *
 * Exemplos:
 *
 * Digite um numero: 7
 * 1 7
 *
 * Digite um numero: 12
 * 1 2 3 4 6 12
 */

int main()
{
    int a, b, c;
    printf("digite um numero:");
    scanf("%i", &a);
    for (b = 1; b < a; b++){
        c = a % b;
        if (c == 0)
            printf("%i ", b);
    }
    printf("%i", a);
    return 0;
}
